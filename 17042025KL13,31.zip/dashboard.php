<?php
include_once "include/header.php";


if(!$user_obj->checkLoginStatus($_SESSION['user'] ['id'])){
	header("Location: login.php");
	exit;
}
$category = $_GET['category'] ?? '';
$search = $_GET['search'] ?? '';

$books = getBooks($pdo, $category, $search);
$bookResult = $books['success'] ? $books['data'] : [];

$catResult = getAllCategories($pdo);
$allCategories = $catResult['success'] ? $catResult['data'] : [];

?>





 <div class="container mt-5">
    <!-- Filter Form Above the Table -->
    <form method="GET" action="" class="mb-4">
        <div class="row">
            <!-- Search Bar -->
            <div class="col-md-6 mb-3">
                <input type="text" name="search" class="form-control" placeholder="Search Products/author/genre" value="<?= htmlspecialchars($search ?? '') ?>">
            </div>

            <!-- Category Filter -->
            <div class="col-md-6 mb-3">
                <select name="category" class="form-select">
                    <option value="">All Categories</option>
                    <?php foreach ($allCategories as $cat): ?>
                        <option value="<?= htmlspecialchars($cat['cat_name']) ?>" <?= isset($category) && $category === $cat['cat_name'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['cat_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Submit Button -->
            <div class="col-12">
                <button type="submit" class="btn btn-primary">Apply Filters</button>
            </div>
        </div>
    </form>

    <!-- Product Table -->
    <div class="table-responsive">
        <table class="table table-hover" id="inventory-table">
            <thead class="table-light">
                <tr>
                    <th>Bild</th>
                    <th>Titel</th>
                    <th>Info</th>
                    <th>Pris</th>
                    <th>År</th>
                    <th>Kategori</th>
                    <th>Åtgärder</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($books['success']) && !empty($books['data'])): ?>
                    <?php foreach ($books['data'] as $book): ?>
                        <tr>
                            <td>
                                <img src="path_to_images/<?= htmlspecialchars($book['prod_code']) ?>.jpg"
                                     alt="<?= htmlspecialchars($book['prod_title']) ?>"
                                     class="img-fluid"
                                     style="max-width: 100px;">
                            </td>
                            <td><?= htmlspecialchars($book['prod_title']) ?></td>
                            <td><?= htmlspecialchars($book['prod_info']) ?></td>
                            <td>$<?= number_format($book['prod_price'], 2) ?></td>
                            <td><?= htmlspecialchars($book['prod_year']) ?></td>
                            <td><?= htmlspecialchars($book['cat_name']) ?></td>
                            <td>
                                <a href="edit-product.php?id=<?= $book['prod_id'] ?>" class="btn btn-primary btn-sm">View Details</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7">
                            <div class="alert alert-warning text-center mb-0">No products found based on your filters.</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
