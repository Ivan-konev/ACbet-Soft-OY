<?php

session_start();

$host = '127.0.0.1';
$user = 'root';
$pass = '';
$dbname = '2025_login'; // Correct database name

// Create mysqli connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check for any connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    echo "✅ Connected to database: " . $dbname;
}

?>
