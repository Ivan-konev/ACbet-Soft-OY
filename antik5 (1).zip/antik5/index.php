<?php
require "include/header-visitor.php";

$category = $_GET['category'] ?? '';
$search = $_GET['search'] ?? '';

$books = getBooks($pdo, $category, $search);
$bookResult = $books['success'] ? $books['data'] : [];

$catResult = getAllCategories($pdo);
$allCategories = $catResult['success'] ? $catResult['data'] : [];
?>

<!-- Search and Filter Section -->
<section class="container mt-5">
    <form method="GET" action="index.php" class="p-4 bg-white rounded shadow-sm">
        <div class="row align-items-end g-3">
            <!-- Search -->
            <div class="col-md-6">
                <label for="search" class="form-label">Search</label>
                <input type="text" id="search" name="search" class="form-control" placeholder="Search products, authors, or genres" value="<?= htmlspecialchars($search) ?>">
            </div>

            <!-- Category Filter -->
            <div class="col-md-4">
                <label for="category" class="form-label">Category</label>
                <select id="category" name="category" class="form-select">
                    <option value="">All Categories</option>
                    <?php foreach ($allCategories as $cat): ?>
                        <option value="<?= htmlspecialchars($cat['cat_name']) ?>" <?= $category === $cat['cat_name'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['cat_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Button -->
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">Apply</button>
            </div>
        </div>
    </form>
</section>

<!-- Product Cards Section -->
<section class="container mt-5">
    <div class="row">
        <?php if (!empty($bookResult)): ?>
            <?php foreach ($bookResult as $book): ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100 shadow-sm">
                        <img src="images/<?= htmlspecialchars($book['prod_code']) ?>.jpg" class="card-img-top" alt="<?= htmlspecialchars($book['prod_title']) ?>">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?= htmlspecialchars($book['prod_title']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($book['prod_info']) ?></p>
                            <p class="card-price fw-semibold text-success">$<?= number_format($book['prod_price'], 2) ?></p>
                            <p class="card-year small text-muted">Year: <?= htmlspecialchars($book['prod_year']) ?></p>
                            <p class="card-cat small text-muted">Category: <?= htmlspecialchars($book['cat_name']) ?></p>

                            <?php if (!empty($book['author_name'])): ?>
                                <p class="card-author small">Author: <strong><?= htmlspecialchars($book['author_name']) ?></strong></p>
                            <?php endif; ?>

                            <?php if (!empty($book['genre_name'])): ?>
                                <p class="card-genre small">Genre: <strong><?= htmlspecialchars($book['genre_name']) ?></strong></p>
                            <?php endif; ?>

                            <a href="product-detail.php?id=<?= $book['prod_id'] ?>" class="btn btn-primary mt-auto">View Details</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-warning text-center p-4">
                    <strong>No products found</strong><br>
                    Try adjusting your search or filter options.
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>

</body>
</html>
