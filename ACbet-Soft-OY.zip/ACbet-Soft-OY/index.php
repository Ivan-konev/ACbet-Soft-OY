<?php
require "include/header-visitor.php";

$category = $_GET['category'] ?? '';
$search = $_GET['search'] ?? '';

$books = getBooks($pdo, $category, $search);
$bookResult = $books['success'] ? $books['data'] : [];

$catResult = getAllCategories($pdo);
$allCategories = $catResult['success'] ? $catResult['data'] : [];
?>

<!-- Search and Filter Section -->
<div class="hero-container position-relative">
        <img src="hero.webp" alt="Karis Antikvariat" class="hero-image w-100">
        <div class="container">
            <div class="hero-content position-absolute">
                <div class="hero-text-container p-5 rounded text-center">
                    <h1>Välkommen till Karis Antikvariat</h1>
                    <p class="lead">Din lokala antikvariat med ett brett utbud av böcker, musik och samlarobjekt</p>
                    <a href="#browse" class="btn btn-primary btn-lg mt-3">Bläddra i vårt sortiment</a>
                </div>
            </div>
        </div>
    </div>

<section class="container mt-5">
<h2>Sök i vårt sortiment</h2>
    <form method="GET" action="index.php" class="p-4">
        <div class="row align-items-end g-3">
            <!-- Search -->
            <div class="col-md-6">
                <label for="search" class="form-label">Search</label>
                <input type="text" id="search" name="search" class="form-control" placeholder="Search products, authors, or genres" value="<?= htmlspecialchars($search) ?>">
            </div>

            <!-- Category Filter -->
            <div class="col-md-4">
                <label for="category" class="form-label">Category</label>
                <select id="category" name="category" class="form-select">
                    <option value="">All Categories</option>
                    <?php foreach ($allCategories as $cat): ?>
                        <option value="<?= htmlspecialchars($cat['cat_name']) ?>" <?= $category === $cat['cat_name'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['cat_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Button -->
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">Apply</button>
            </div>
        </div>
    </form>
</section>

<!-- Product Cards Section -->
<section class="container mt-5">
    <div class="row">
    <table class="table table-hover" id="inventory-table">
            <thead class="table-light">
                <tr>
                    <th>Titel</th>
                    <th>Författare</th>
                    <th>Kategori</th>
                    <th>Genre</th>
                    <th>Bok skick</th>
                    <th>Pris</th>
                </tr>
            </thead>
            <tbody>
        <?php if (!empty($bookResult)): ?>
            <?php foreach ($bookResult as $book): ?>
                <tr onclick="window.location='product-detail.php?id=<?= $book['prod_id'] ?>';" style="cursor:pointer;">
                            <td><?= htmlspecialchars($book['prod_title']) ?></td>
                            <td><?= htmlspecialchars($book['author_name']) ?></td>
                            <td><?= htmlspecialchars($book['cat_name']) ?></td>
                            <td><?= htmlspecialchars($book['genre_name']) ?></td>
                            <td><?= htmlspecialchars($book['cond_class']) ?></td>
                            <td>€<?= number_format($book['prod_price'], 2) ?></td>
                        </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-warning text-center p-4">
                    <strong>No products found</strong><br>
                    Try adjusting your search or filter options.
                </div>
            </div>
        <?php endif; ?>
     </tbody>
</table>
    </div>
</section>

</body>
</html>
