<?php
// delete-product.php

include_once "include/header.php";

if (isset($_GET['uid']) && is_numeric($_GET['uid'])) {
    $productId = (int)$_GET['uid'];

    if (isset($_POST['confirm']) && $_POST['confirm'] === "delete") {
        $result = deleteProduct($pdo, $productId);

        if ($result['success']) {
            header("Location: dashboard.php?deletedproduct=1");
            exit;
        } else {
            $productFeedback = $result['message'];
        }
    }
} else {
    echo "<div class='alert alert-danger'>Invalid product ID.</div>";
    exit;
}
?>
