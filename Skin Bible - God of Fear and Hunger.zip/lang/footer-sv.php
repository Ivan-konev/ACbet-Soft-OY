<?php
$footer_text = [
    'contact' => 'Karis Antikvariat',
    'address' => 'Köpmansgatan 12, 10300 Karis',
    'phone' => '040-8719706',
    'email' => 'karisantikvariat@gmail.com',
    'opening_hours' => 'Öppettider',
    'delivery' => 'Leverans',
    'delivery_text' => 'Vi levererar via Posti enligt deras prislistor. Vi levererar även utomlands.',
    'tue_fri' => 'Tisdag - Fredag: 10:00 - 17:00',
    'sat' => 'Lördag: 10:00 - 15:00',
    'sun_mon' => 'Söndag - Måndag: Stängt',
    'rights' => '&copy; 2025 Axxell. Alla rättigheter förbehållna.',
    'facebook' => '@antikvariatkaris',
];
