<?php
include_once "include/header.php";


if (isset($_POST['add-product'])) {
    $success = insertBook($pdo, $_POST);

   if ($success) {
    echo '<div class="alert alert-success" role="alert">
            Book inserted successfully!
          </div>';
    // Optional: Redirect user
    // header("Location: success_page.php");
    // exit;
} else {
    echo '<div class="alert alert-danger" role="alert">
            Error inserting the book.
          </div>';
}
}

if (isset($_POST['add_category'])) {
    $newCategory = $_POST['new_category'] ?? '';

    if (addCategory($pdo, $newCategory)) {
        // Category added successfully, reload page to refresh dropdown
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    } else {
        // Optionally set an error message (if you want)
        $error = "Category already exists or could not be added.";
    }
}

if (isset($_POST['add_genre'])) {
    $newGenre = $_POST['new_genre'] ?? '';

    if (addGenre($pdo, $newGenre)) {
        // Genre added successfully, reload page to refresh dropdown
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    } else {
        // Optional: set error message
        $error = "Genre already exists or could not be added.";
    }
}



?>



<div class="container mt-5">
	<div class="row justify-content-center">
		<h2 class="mb-4">Add New Book</h2>
		<form action="" method="POST" class="needs-validation" novalidate>
		  <div class="row mb-3">
			<div class="col-md-6">
			  <label for="title" class="form-label">Title</label>
			  <input type="text" name="title" id="title" class="form-control" required>
			</div>

			<div class="col-md-6">
				<label for="category" class="form-label">Category</label>
				<div class="input-group">
					<select name="category" id="category" class="form-select" required>
						<?= renderCategorySelect($pdo, $category ?? '') ?>
					</select>
					<button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
						Add
					</button>
				</div>
			</div>
		  </div>

		  <div class="row mb-3">
			<div class="col-md-6">
			  <label for="author" class="form-label">Author</label>
			  <input type="text" name="author" id="author" class="form-control" required>
			</div>

			<div class="col-md-6">
				<label for="genre" class="form-label">Genre</label>
				<div class="input-group">
					<select name="genre" id="genre" class="form-select" required>
						<?= renderGenreSelect($pdo, $genre ?? '') ?>
					</select>
					<button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#addGenreModal">
						Add
					</button>
				</div>
			</div>
		  </div>

		  <div class="row mb-3">
			<div class="col-md-4">
			  <label for="shelf" class="form-label">Shelf Number</label>
			  <input type="text" name="shelf" id="shelf" class="form-control" required>
			</div>

			<div class="col-md-4">
			  <label for="price" class="form-label">Price ($)</label>
			  <input type="number" step="0.01" name="price" id="price" class="form-control" required>
			</div>

			<div class="col-md-4">
			  <label for="year" class="form-label">Year</label>
			  <input type="number" name="year" id="year" class="form-control" required>
			</div>
		  </div>

		  <div class="mb-3">
			<label for="condition" class="form-label">Condition</label>
			<select name="condition" id="condition" class="form-select" required>
			  <option value="New">New</option>
			  <option value="Good">Good</option>
			  <option value="Fair">Fair</option>
			  <option value="Used">Used</option>
			  <option value="Damaged">Damaged</option>
			</select>
		  </div>

		  <button type="submit" class="btn btn-primary" name="add-product">Add Book</button>
		</form>
	</div>
</div>


<!-- Add Genre Modal -->
<div class="modal fade" id="addGenreModal" tabindex="-1" aria-labelledby="addGenreModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="post">
        <div class="modal-header">
          <h5 class="modal-title" id="addGenreModalLabel">Add New Genre</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label for="new_genre" class="form-label">Genre Name</label>
            <input type="text" class="form-control" id="new_genre" name="new_genre" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" name="add_genre" class="btn btn-primary">Add Genre</button>
        </div>
      </form>
    </div>
  </div>
</div>


<div class="modal fade" id="addCategoryModal" tabindex="-1" aria-labelledby="addCategoryModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST" action="">
        <div class="modal-header">
          <h5 class="modal-title" id="addCategoryModalLabel">Add New Category</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label for="newCategoryName" class="form-label">Category Name</label>
            <input type="text" class="form-control" id="newCategoryName" name="new_category" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" name="add_category"  class="btn btn-primary">Save Category</button>
        </div>
      </form>
    </div>
  </div>
</div>