<?php
$footer_text = [
    'contact' => 'Karisin Antikvariaatti',
    'address' => 'Kauppiaankatu 12, 10300 Karjaa',
    'phone' => '040-8719706',
    'email' => 'karisantikvariat@gmail.com',
    'opening_hours' => 'Aukioloajat',
    'delivery' => 'Toimitus',
    'delivery_text' => 'Toimitamme Postin hinnaston mukaan. Toimitamme myös ulkomaille.',
    'tue_fri' => 'Tiistai - Perjantai: 10:00 - 17:00',
    'sat' => 'Lauantai: 10:00 - 15:00',
    'sun_mon' => 'Sunnuntai - Maanantai: Suljettu',
    'rights' => '&copy; 2025 Axxell. Kaikki oikeudet pidätetään.',
    'facebook' => '@antikvariatkaris',
];
