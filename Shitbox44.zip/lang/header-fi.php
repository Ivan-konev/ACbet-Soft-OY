<?php
$header_text = [
    'title' => 'Antikvariaatti',
    'brand' => 'Karjaan Antikvariaatti',
    'about_us' => 'Meistä',
    'home' => 'Etusivu',
    'lang_sv' => 'SV',
    'lang_fi' => 'FI',
];
