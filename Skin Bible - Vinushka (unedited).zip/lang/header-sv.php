<?php
$header_text = [
     'title' => 'Antikvariat',
    'brand' => 'Karis Antikvariat',
    'about_us' => 'Om oss',
    'home' => 'Hem',
    'lang_sv' => 'SV',
    'lang_fi' => 'FI',
];
