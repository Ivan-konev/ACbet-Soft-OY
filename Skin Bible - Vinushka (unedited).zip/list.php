<?php



include_once "include/header.php";

if (!isset($_SESSION['user']) || !$user_obj->checkUserRole($_SESSION['user']['role'], [200, 300, 9999])) {
    $_SESSION['access_denied'] = "You do not have permission to access that page.";
    header('Location: dashboard.php');
    exit;
}

// Handle export via POST, not GET
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['export_csv']) && $_POST['export_csv'] == '1') {
    // Pass filter parameters explicitly from POST or fallback to GET (filters are from GET)
    $category   = $_POST['category'] ?? $_GET['category'] ?? '';
    $search     = $_POST['search']   ?? $_GET['search']   ?? '';
    $year_from  = $_POST['year_from'] ?? $_GET['year_from'] ?? '';
    $year_to    = $_POST['year_to'] ?? $_GET['year_to'] ?? '';
    $price_min  = $_POST['price_min'] ?? $_GET['price_min'] ?? '';
    $price_max  = $_POST['price_max'] ?? $_GET['price_max'] ?? '';
    $status     = $_POST['status'] ?? $_GET['status'] ?? '';
    // Make sure to pass sort/order as well if you want (here defaulted)
    exportBooksAsCSV($pdo, $category, $search, $year_from, $year_to, $price_min, $price_max, $status);
    exit;  // Important to stop script after export
}

// GET filters (for display & fetching books)
$category = $_GET['category'] ?? '';
$search = $_GET['search'] ?? '';
$year_from = $_GET['year_from'] ?? '';
$year_to = $_GET['year_to'] ?? '';
$price_min = $_GET['price_min'] ?? '';
$price_max = $_GET['price_max'] ?? '';
$status = $_GET['status'] ?? '';

// Fetch data using the correct getBooks call (with sort/order params)
$result = getBooks($pdo, $category, $search, $year_from, $year_to, $price_min, $price_max, $status, 'p.prod_title', 'ASC');
$bookResult = $result['success'] ? $result['data'] : [];

$catResult = getAllCategories($pdo);
$allCategories = $catResult['success'] ? $catResult['data'] : [];

// Handle status toggle
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'], $_POST['current_status'])) {
    $productId = (int) $_POST['product_id'];
    $newStatus = $_POST['current_status'] == 1 ? 0 : 1;
    $result = updateProductStatus($pdo, $productId, $newStatus);
    echo "<p>{$result['message']}</p>";
}

// Access denied modal
if (isset($_SESSION['access_denied'])) {
    $message = $_SESSION['access_denied'];
    unset($_SESSION['access_denied']);
    echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            let modal = new bootstrap.Modal(document.getElementById('accessDeniedModal'));
            modal.show();
        });
    </script>";
}



?>

<ul class="nav nav-tabs" id="inventory-tabs">
    <li class="nav-item"><a class="nav-link active" href="dashboard.php">Sök</a></li>
    <li class="nav-item"><a class="nav-link" href="create-product.php">Lägg till objekt</a></li>
    <li class="nav-item"><a class="nav-link" href="database-edit.php">Redigera databas</a></li>
    <li class="nav-item"><a class="nav-link" href="list.php">Listor</a></li>
</ul>

<?php if (isset($_GET['updated']) && $_GET['updated'] == 1): ?>
    <div class="alert alert-success"><p class="text-center m-0">Book updated successfully.</p></div>
<?php endif; ?>

<?php if(isset($_GET['deleted'])): ?>
    <div class="alert alert-success"><p class="text-center m-0">Product deleted successfully</p></div>
<?php endif; ?>

<div class="container mt-5">
    <form method="GET" action="" class="mb-4">
        <div class="row">
            <!-- Search Bar -->
            <div class="col-md-4 mb-3">
                <input type="text" name="search" class="form-control" placeholder="Search Products/Author/Genre" value="<?= htmlspecialchars($search) ?>">
            </div>

            <!-- Category Filter -->
            <div class="col-md-4 mb-3">
                <select name="category" class="form-select">
                    <option value="">All Categories</option>
                    <?php foreach ($allCategories as $cat): ?>
                        <option value="<?= htmlspecialchars($cat['cat_name']) ?>" <?= $category === $cat['cat_name'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['cat_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Status Filter -->
            <div class="col-md-4 mb-3">
                <select name="status" class="form-select">
                    <option value="">All Statuses</option>
                    <option value="1" <?= $status === '1' ? 'selected' : '' ?>>Tillgänglig</option>
                    <option value="0" <?= $status === '0' ? 'selected' : '' ?>>Såld</option>
                </select>
            </div>

            <!-- Year Range -->
            <div class="col-md-3 mb-3">
                <input type="number" name="year_from" class="form-control" placeholder="Year From" value="<?= htmlspecialchars($year_from) ?>">
            </div>
            <div class="col-md-3 mb-3">
                <input type="number" name="year_to" class="form-control" placeholder="Year To" value="<?= htmlspecialchars($year_to) ?>">
            </div>

            <!-- Price Range -->
            <div class="col-md-3 mb-3">
                <input type="number" step="0.01" name="price_min" class="form-control" placeholder="Min Price" value="<?= htmlspecialchars($price_min) ?>">
            </div>
            <div class="col-md-3 mb-3">
                <input type="number" step="0.01" name="price_max" class="form-control" placeholder="Max Price" value="<?= htmlspecialchars($price_max) ?>">
            </div>

            <!-- Submit and Export Buttons -->
			<div class="col-12 mt-2">
				<button type="submit" class="btn btn-primary">Apply Filters</button>
				
			</div>
        </div>
    </form>
	<!-- Separate form for export -->
	<form method="POST" action="" class="mb-4" id="export-form">
		<!-- Include hidden inputs to pass current filter values -->
		<input type="hidden" name="category" value="<?= htmlspecialchars($category) ?>">
		<input type="hidden" name="search" value="<?= htmlspecialchars($search) ?>">
		<input type="hidden" name="year_from" value="<?= htmlspecialchars($year_from) ?>">
		<input type="hidden" name="year_to" value="<?= htmlspecialchars($year_to) ?>">
		<input type="hidden" name="price_min" value="<?= htmlspecialchars($price_min) ?>">
		<input type="hidden" name="price_max" value="<?= htmlspecialchars($price_max) ?>">
		<input type="hidden" name="status" value="<?= htmlspecialchars($status) ?>">
		<button type="submit" name="export_csv" value="1" class="btn btn-success">Export CSV</button>
	</form>

    <!-- Product Table -->
    <div class="table-responsive">
        <table class="table table-hover">
            <thead class="table-light">
                <tr>
                    <th>Id</th>
                    <th>Titel</th>
                    <th>Författare</th>
                    <th>Kategori</th>
                    <th>Pris</th>
                    <th>År</th>
                    <th>Status</th>
                    <th>Åtgärder</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($bookResult)): ?>
                    <?php foreach ($bookResult as $book): ?>
                        <tr onclick="window.location='edit-product.php?id=<?= $book['prod_id'] ?>';" style="cursor:pointer;">
                            <td><?= htmlspecialchars($book['prod_id']) ?></td>
                            <td><?= htmlspecialchars($book['prod_title']) ?></td>
                            <td><?= htmlspecialchars($book['author_names']) ?></td>
                            <td><?= htmlspecialchars($book['cat_name']) ?></td>
                            <td>$<?= number_format($book['prod_price'], 2) ?></td>
                            <td><?= htmlspecialchars($book['prod_year']) ?></td>
                            <td>
                                <?= $book['prod_status'] == 1 ? '<p class="text-success">Tillgänglig</p>' : '<p class="text-danger">Såld</p>' ?>
                            </td>
                            <td>
                                <form method="POST" onClick="event.stopPropagation();" style="display:inline;">
                                    <input type="hidden" name="product_id" value="<?= $book['prod_id'] ?>">
                                    <input type="hidden" name="current_status" value="<?= $book['prod_status'] ?>">
                                    <label class="switch">
                                        <input type="checkbox" name="toggle_status" onchange="this.form.submit()" <?= $book['prod_status'] ? 'checked' : '' ?>>
                                        <span class="slider round"></span>
                                    </label>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8"><div class="alert alert-warning text-center mb-0">No products found based on your filters.</div></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
		
    </div>
</div>

<div class="modal fade" id="accessDeniedModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title">Access Denied</h5></div>
      <div class="modal-body"><?= htmlspecialchars($message ?? '') ?></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>
      </div>
    </div>
  </div>
</div>


<style>
.switch {
  position: relative;
  display: inline-block;
  width: 50px;
  height: 24px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #f44336;
  transition: .4s;
  border-radius: 24px;
}

.slider:before {
  position: absolute;
  content: "";
  height: 18px;
  width: 18px;
  left: 3px;
  bottom: 3px;
  background-color: white;
  transition: .4s;
  border-radius: 50%;
}

input:checked + .slider {
  background-color: #4caf50;
}

input:checked + .slider:before {
  transform: translateX(26px);
}
</style>
