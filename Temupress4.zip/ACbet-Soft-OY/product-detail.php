<?php
// product_detail.php
include('include/config.php');  // Include your database connection

if (isset($_GET['id'])) {
    $prod_id = $_GET['id'];

    $query = "
        SELECT 
            p.prod_id, p.prod_title, p.prod_info, p.prod_price, p.prod_year,
            c.cat_name, s.shelf_nr, k.cond_class
        FROM products p
        LEFT JOIN tab_cat c ON p.prod_cat_fk = c.cat_id
        LEFT JOIN tab_shelf s ON p.prod_shelf_fk = s.shelf_id
        LEFT JOIN tab_kond k ON p.prod_cond_fk = k.cond_id
        WHERE p.prod_id = ?
    ";

    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param('i', $prod_id); // 'i' for integer (prod_id)
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $product = $result->fetch_assoc();
        } else {
            echo "Product not found.";
            exit;
        }
    } else {
        echo "Error: " . $conn->error;
        exit;
    }
} else {
    echo "No product ID provided.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Detail</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-6">
            <img src="path_to_image.jpg" class="img-fluid" alt="Product Image">
        </div>
        <div class="col-md-6">
            <h2><?php echo htmlspecialchars($product['prod_title']); ?></h2>
            <p><strong>Category:</strong> <?php echo htmlspecialchars($product['cat_name']); ?></p>
            <p><strong>Condition:</strong> <?php echo htmlspecialchars($product['cond_class']); ?></p>
            <p><strong>Price:</strong> $<?php echo htmlspecialchars($product['prod_price']); ?></p>
            <p><strong>Year:</strong> <?php echo htmlspecialchars($product['prod_year']); ?></p>
            <p><strong>Shelf:</strong> <?php echo htmlspecialchars($product['shelf_nr']); ?></p>
            <p><?php echo nl2br(htmlspecialchars($product['prod_info'])); ?></p>
            <a href="index.php" class="btn btn-secondary">Back to Shop</a>
        </div>
    </div>
</div>

</body>
</html>
